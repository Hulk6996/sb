import {encoded, translations} from './data.js'

console.log("Let's rock")
console.log(encoded, translations)



// console.log(decoded)
